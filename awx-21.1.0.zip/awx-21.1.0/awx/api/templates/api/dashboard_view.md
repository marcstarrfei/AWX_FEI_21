Make a GET request to this resource to retrieve aggregate statistics for Tower.
