Make a GET request to this resource to obtain a list all Receptor Nodes and their links.
